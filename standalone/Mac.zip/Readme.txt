Welcome to edX-dl
=================

edX-dl is a simple tool to download video lectures from edx.org. 

For suggestions or bug reports or to download latest packages, please visit https://github.com/coiby/edx-downloader.


Usage
-----

Open the file `config` using text editor, replace yourusername, yourpassword with your own username and password. 

For Windows users, double click `edx-dl.bat` to execute the program. For Linux and Mac users, execute `edx-dl` from terminal.

Notes
------
There are some videos hosted only on youtube, you need to install `youtube-dl`. Please visit http://rg3.github.io/youtube-dl/download.html.

Credits
-------
The original file was written by @shk3 in/for python3 then updated by @emadshaaban92 for python2, and migrated for versions superior to 2.6 by @iemejia, then updated and converted to stand-alone executables by @coiby.
